class CamelCase:
    def __init__(self):
        self.sentence = ''
    def camelCase(self):
        self.sentence = ''.join(x for x in self.sentence.title() if x.isalnum())
        return self.sentence[0].lower() + self.sentence[1:]

def main():

    string = CamelCase()
    newString = CamelCase.camelCase(string)





main()
